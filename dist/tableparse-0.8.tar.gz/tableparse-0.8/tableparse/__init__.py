from .tableparse import *

__name__ = "tableparse"
__license__ = 'MIT'
__author__ = "Tommy Gymer"